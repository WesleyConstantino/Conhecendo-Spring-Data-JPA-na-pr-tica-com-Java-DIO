/**
 * Spring Data JPA specific ThreeTenBp converters.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.jpa.convert.threetenbp;
