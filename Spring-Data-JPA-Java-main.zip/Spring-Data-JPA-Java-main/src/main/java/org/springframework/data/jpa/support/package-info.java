/**
 * Various helper classes useful when working with JPA.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.jpa.support;
